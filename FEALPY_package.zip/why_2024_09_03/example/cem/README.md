# 计算电磁学（Computational Electromagnetics）

该目录下存放的是基于 FEALPy 开发的计算电磁学的相关示例。

This directory contains examples of computational electromagnetism developed based
on FEALPy.
