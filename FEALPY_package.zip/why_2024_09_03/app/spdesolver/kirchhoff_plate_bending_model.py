#!/usr/bin/python3

import numpy as np

from fealpy.decorator import cartesian

class KrichhoffplateData:

    @cartesian
    def __init__(sefl, D=):
        """
        @brief 模型初始化函数
        """
        self._doamin = 

    def doamin(self):
        """
        @berif 
        """
        return self._doamin

    @cartesian
    def solution(self, ):
        pass

    def neuman(self):
        """
        @berif Neuman boundary condition
        """
        pass
