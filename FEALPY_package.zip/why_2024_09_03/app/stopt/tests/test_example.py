# test_example.py

def test_addition():
    assert 1 + 1 == 2

def test_subtraction():
    assert 2 - 1 == 1

def test_multiplication():
    assert 2 * 3 == 6

def test_division():
    assert 10 / 2 == 5
