import numpy as np
from enum import Enum

class MeshingType(Enum):
    # 三角形
    TRIANGLE = 1
    # 四边形
    QUADRILATERAL = 2

