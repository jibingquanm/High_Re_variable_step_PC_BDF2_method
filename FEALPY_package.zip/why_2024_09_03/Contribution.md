# 贡献者

| 姓名   | 邮箱                        | github账号    |
| ------ | --------------------------- | ------------- |
| 陈春雨 | cbtxs@smail.xtu.edu.cn      | cbtxs         |
| 田甜   | tiantian0347@126.com        | tiantian0347  |
| 王栋   |                             | wangdong19    |
| 王鹏祥 | 2016750202@smail.xtu.edu.cn | WPengXiang    |
| 高婷艺 |                             | gaotingyi     |
| 田昊伦 | 2250213115@qq.com           |  ChaosTHL     |
| 陈康   | ck1193838646@163.com        | concha-k-chen |

| 郑仰阳 | zhengyy0621@foxmail.com     | AlbertZyy     |
| 彭淼颖 | 530334303@qq.com            |               |
| 刘琴   | 2655493031@qq.com           | BellaLq       |
| 何亮   | 894758682@qq.com            | brighthe      |
| 刘嘉旺 | 15674760037@163.com         | Liujiawangmath|
| 汪文彬 | 1243702877@qq.com           | Wangwenbinmath|
| 张靖红 | 2444579586@qq.com           | JinghongZhang0707|
| 刘志   | 1985547582@qq.com           | july-liuzhi   |
| 黄春蕾 | hcc202211@163.com           |Huangchunleimath|
| 刘洋   | 89122231@qq.com             | liuyang778    |
| 丁人杰 | 18379451180@163.com         | Dingrenjiemath|
| 陈潮林 | 2767709137@qq.com           | Chaolinmath   |
