---
title: 线弹性问题求解
permalink: /docs/en/num-linear-elasticity
key: docs-linear-elasticity-en
---
