---
title: Navier-stokes 方程数值求解
permalink: /docs/en/num-navier-stokes-equation
key: docs-num-navier-stoke-equation-en
---
