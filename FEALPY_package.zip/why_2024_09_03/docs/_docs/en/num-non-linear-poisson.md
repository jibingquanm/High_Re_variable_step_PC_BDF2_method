---
title: Numerical Solution for Non-linear Poisson Equation
permalink: /docs/en/num-non-linear-poisson
key: docs-num-non-linear-poisson-en
---
