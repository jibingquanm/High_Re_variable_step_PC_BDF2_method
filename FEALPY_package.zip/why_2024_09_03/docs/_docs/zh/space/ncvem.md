---
title: 非协调虚单元方法
permalink: /docs/zh/space/ncvem
key: docs-ncvem-zh
---
