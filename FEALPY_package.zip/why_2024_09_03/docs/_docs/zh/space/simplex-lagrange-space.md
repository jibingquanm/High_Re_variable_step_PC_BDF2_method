---
title: 单纯形网格上的拉格朗日有限元空间 
permalink: /docs/zh/space/simplex-lagrange-space
key: docs-simplex-lagrange-space-zh
---

# 重心坐标
