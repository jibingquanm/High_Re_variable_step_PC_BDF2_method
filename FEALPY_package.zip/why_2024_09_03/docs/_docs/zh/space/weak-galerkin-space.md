---
title: Weak Galerkin 方法 
permalink: /docs/zh/space/weak-galerkin-space
key: docs-weak-galerkin-space-zh
---
