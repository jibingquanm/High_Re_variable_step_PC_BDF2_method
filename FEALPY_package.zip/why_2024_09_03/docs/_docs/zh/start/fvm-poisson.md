---
title: 有限体积求解 Poisson 方程
permalilink: /docs/zh/start/fvm-poisson
key: docs-quick-start-fvm-poisson-zh
---
