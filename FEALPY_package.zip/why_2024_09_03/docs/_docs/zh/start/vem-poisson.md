---
title: 虚单元积求解 Poisson 方程
permalilink: /docs/zh/start/vem-poisson
key: docs-quick-start-vem-poisson-zh
---
