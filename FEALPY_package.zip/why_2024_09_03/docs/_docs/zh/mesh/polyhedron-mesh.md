---
title: 多面体网格
permalink: /docs/zh/mesh/polyhedron-mesh
key: docs-polyhedron-mesh-zh
---
