---
title: 矩阵组装
permalink: /docs/zh/assemble/matrix
key: docs-matrix-zh
---
