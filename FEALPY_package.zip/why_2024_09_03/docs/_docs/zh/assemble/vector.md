---
title: 向量组装
permalink: /docs/zh/assemble/vector
key: docs-vector-zh
---
