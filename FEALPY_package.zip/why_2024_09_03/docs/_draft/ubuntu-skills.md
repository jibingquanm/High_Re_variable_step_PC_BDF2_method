
# 增加用户

```
sudo adduser name
```
