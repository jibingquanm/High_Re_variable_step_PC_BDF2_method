# 湘大 vpn 访问

1. 访问 https://vpn.xtu.edu.cn 下载对应系统的 easyconnect 安装
2. 打开 easyconnect, 输入湘大的 vpn 服务器地址 https://vpn.xtu.edu.cn 
3. 输入你的帐号和密码即可访问


